
# Programming project

## Group elements

Identify all group elements (numbers and names).

- upXXXXX Name of element 1
- upXXXXX Name of element 2
- upXXXXX Name of element 3


## Accomplished tasks

Brief summary of what you implemented.


